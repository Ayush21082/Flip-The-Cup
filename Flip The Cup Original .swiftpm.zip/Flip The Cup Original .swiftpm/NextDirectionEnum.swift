//
//  NextDirectionEnum.swift
//  Flip the Can
//
//  Created by Ayush Singh on 22/04/22.
//

enum NextDirection: Int {
    case left       = 0
    case right      = 1
}
