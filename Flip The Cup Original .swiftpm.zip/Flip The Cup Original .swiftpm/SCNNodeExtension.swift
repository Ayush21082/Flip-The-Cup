//
//  SCNNodeExtension.swift
//  Flip the Can
//
//  Created by Ayush Singh on 22/04/22.
//

import SceneKit

extension SCNNode {
    
    func isNotContainedXZ(in boxNode: SCNNode) -> Bool {
        let box = boxNode.geometry as! SCNBox
        let width = Float(box.width)
        if abs(position.x - boxNode.position.x) > width / 2.0 {
            return true
        }
        if abs(position.z - boxNode.position.z) > width / 2.0 {
            return true
        }
        return false
    }
    
}
