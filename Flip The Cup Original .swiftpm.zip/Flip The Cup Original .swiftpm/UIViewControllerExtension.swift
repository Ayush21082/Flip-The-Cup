//
//  UIViewControllerExtension.swift
//  Flip the Can
//
//  Created by Ayush Singh on 22/04/22.
//


import UIKit

extension UIViewController {
    
    func alert(message: String) {
        DispatchQueue.main.async {

        let alertController = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
}
