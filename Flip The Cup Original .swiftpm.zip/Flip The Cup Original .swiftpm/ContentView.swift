

import SwiftUI
import AVKit

struct ContentView: View {
    var body: some View {
        
        ZStack {
            CustomVCReprestable()
            
        }
    }
    
    public init() {}
}

struct Introduction: View {
    
    @State var isModal: Bool = false
    
    var body: some View {
        
        
        ZStack {
            Color.white
            ZStack{}
                .frame( maxWidth: .infinity, maxHeight: .infinity)
                .background(Image("home-shape").resizable())
                .ignoresSafeArea()
            
            
            VStack {
                HStack {
                    
                    VStack(alignment: .leading) {
                        
                        Text("Hii! 👋🏻 I'am Ayush Singh")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(.black)
                        
                        Text("I'm an astute App, Web Developer, and Designer with a passion for ideation, design, and creation of innovative products. I'm also an Apple  WWDC 2021 Swift Student Challenge winner")
                            .font(.system(size: 15))
                            .fontWeight(.medium)
                            .padding()
                            .foregroundColor(.gray)
                        HStack{
                            Spacer()
                                .frame(width: 20)
                            Button {
                                self.isModal = true
                            } label: {
                                Text("Watch my WWDC22 Project")
                                    .foregroundColor(.blue)
                                    .fontWeight(.bold)
                                    .padding()
                                    .foregroundColor(.black)
                                    .border(.blue, width: 2)
                                    .fullScreenCover(isPresented: $isModal, content: {
                                        HowToUse()
                                    })
                                
                            }
                            
                            
                            
                            
                        }
                        
                        
                    }
                    Spacer()
                    VStack {
                        Image("profile")
                            .resizable()
                            .frame(width: 300, height: 300)
                            .padding()
                        
                        
                        
                        
                    }
                    
                }
                
                
            }
            
            
            
            
            
            
        }
    }
}

struct HowToUse: View {
    
    @State var isIntroduction: Bool = false
    @State var isGame: Bool = false
    @State var isDemo: Bool = false
    
    
    var body: some View {
        
        
        ZStack {
            Color.white
            ZStack{}
                .frame( maxWidth: .infinity, maxHeight: .infinity)
                .background(Image("bg-img").resizable())
                .ignoresSafeArea()
            
            VStack {
                
                VStack (alignment: .center){
                    
                    Text("Flip the cup")
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(.black)
                    
                    Text("You must have heard about flip the cup challenge. What if we give you a platform to enjoy the same kind of vibe. With our ‘Flip the cup’ game, you can enjoy the most realistic game you would have ever played on your iOS devices. This game comes with AR kit technology which surpasses your imagination towards a game. This game comes with 3D model experience that keeps you on the edge of the seat for every jump you make to advance in the game. You are just a tap away to move into this AR powered game.")
                        
                    
                        .font(.system(size: 15))
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(Color.gray)
                        
                    
                    

                }
                
                VStack {
                    
                    Text("How to use")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(.black)
                    HStack {
                    VStack{
                        
                        Text("When the game starts, keep your iPad at the same height as your head.")
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(Color.gray)
                        
                        Text("Find a comfortable angle where AR can detect 3D planes and wait for the alert “press okay to join”,until then please wait patiently.")
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(Color.gray)
                        
                        Text("Once the game starts 2 square boxes will appear and one of them will have a cylindrical shape on top of it, now you have to apply pressure by your fingers or thumb to make it reach to the next square.")
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(Color.gray)
                        
                        Text("As you proceed the score will increase and the number of square boxes will increase simultaneously.")
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(Color.gray)
                        
                        Text("Scoring of game is when you flip the cup and landed to the box you got 1 point then points get increasing, TRY NOT TO MISS and if you missed then you will lose the game.")
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .padding()
                            .foregroundColor(Color.gray)
                    }
                }
                    Spacer()
                }
                
                
            }
            
            
            
            ZStack{
                VStack{
                    Spacer()
                    HStack{
                        Spacer()
                            .frame(width: 20)
                        Button {
                            self.isIntroduction = true
                        } label: {
                            Text("Introduction")
                                .foregroundColor(.blue)
                                .fontWeight(.bold)
                                .padding()
                                .foregroundColor(.black)
                                .border(.blue, width: 2)
                                .fullScreenCover(isPresented: $isIntroduction, content: {
                                    Introduction()
                                })
                            
                        }
                        Spacer()
                        
                        Button {
                            self.isDemo = true
                        } label: {
                            Text("Watch Demo")
                                .foregroundColor(.blue)
                                .fontWeight(.bold)
                                .padding()
                                .foregroundColor(.black)
                                .border(.blue, width: 2)
                                .sheet(isPresented: $isDemo, content: {
                                    Demo()
                                })
                            
                        }
                        
                        Button {
                            self.isGame = true
                        } label: {
                            Text("Play Now")
                                .foregroundColor(.white)
                                .fontWeight(.bold)
                                .padding()
                                .foregroundColor(.black)
                                .background(Color.blue)
                                .fullScreenCover(isPresented: $isGame, content: {
                                    ContentView()
                                })
                            
                        }
                        
                        
                        
                        Spacer()
                            .frame(width: 20)
                    }
                    Spacer()
                        .frame(height: 20)
                }
            }
            
            
            
        }
        
        
    }
}

struct Demo: View {

    let fileUrl = Bundle.main.url(forResource: "demo1", withExtension: "mp4")!
    
    var body: some View {
        VStack {
            HStack{
//                VideoPlayer(player: AVPlayer(url:  URL(string: "https://bit.ly/swswift")!))
                VideoPlayer(player: AVPlayer(url: fileUrl))
            }
        }
    }
}


struct CustomVCReprestable: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> ViewController {
        ViewController()
    }
    
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {}
}
